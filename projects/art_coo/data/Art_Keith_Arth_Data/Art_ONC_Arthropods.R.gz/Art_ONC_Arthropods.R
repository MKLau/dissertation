#Art's Arthropod Data from ONC 2004-2006

#1) PA and relativized data
#2) Include genotype comparison
#3) Combine years
#4) Rarefy out to more trees
#5) Confidence intervals
#6) Year-wise comparison

#NOTES: Majority of species are rare. Shifts in the most abundant species seem to be driving the community patterns produced by genotypes.
#NOTES FROM ART
#Here is a lot of data.  There is a spreadsheet with just richness data for potential accum. curves and then there is all the raw data for three years of arthropods on the narrowleaf trees at ONC.  If you are too busy to mess with the accum. curve stuff then no problem. With the other stuff let me know what you're thinking and if you need anything else. I have some Chem. and growth rate data, I also have this stuff broken down into feeding guilds etc... Thanks for your help ahead of time and I think there is definitely  more we can do with this data and my newer stuff in the future.
#I  realized that the species accumulation curves will have to come from that raw data and I wanted to let you know that of the three years the last (2006) was greater total richness across most if not all genotypes. So I think I would/will try using that year first.just a thought,

#Reading Art's data files
read.art=function(file=""){
x<-read.xls(file,header=TRUE)
xspp<-x[,1]
x<-x[,-1]
x<-t(x)
colnames(x)<-xspp
return(x)
	}

library(gdata)
setwd("/Users/artemis/Documents/R_Docs/Art Keith/Art ONC Arthropods")
ArtONC=list()
for (i in 1:length(dir())){
ArtONC[[i]]=read.art(dir()[i])
names(ArtONC)[i]=strsplit(dir()[i],split=" ")[[1]][1]
	}
names(ArtONC)

#Extract genotype vector from the rownames
geno=list()
for (i in 1:length(dir())){
geno[[i]]<-read.xls(dir()[i],header=FALSE)[1,-1]
names(geno)[i]=paste("geno",strsplit(dir()[i],split=" ")[[1]][1],sep="_")	
	}

library(vegan)
geno040506=geno
geno=factor(as.character(geno040506[[1]]))

#PerMANOVA with the raw data
wPB=list()
for (i in 1:length(ArtONC)){
	x=ArtONC[[i]]
	x=vegdist(x)
	wPB[[i]]=adonis(x~geno,nperm=10000)$aov.tab
	names(wPB)[i]=names(ArtONC)[i]
	}
wPB

#Relativize by species max
rel.results=list()
for (i in 1:length(ArtONC)){
	x=ArtONC[[i]]
	x=decostand(x,'max',2)
	x=vegdist(x)
	rel.results[[i]]=adonis(x~as.numeric(geno[[i]]),nperm=10000)$aov.tab
	names(rel.results)[i]=names(ArtONC)[i]
	}
rel.results

#Remove P. betae and conduct PerMANOVA
noPB=list()
for (i in 1:length(ArtONC)){
	x=ArtONC[[i]]
	x=x[,-(1:length(colnames(x)))[colnames(x)=="PB Gall"]]
	x=vegdist(x)
	noPB[[i]]=adonis(x~as.numeric(geno[[i]]),nperm=10000)$aov.tab
	names(noPB)[i]=names(ArtONC)[i]
	}
noPB

wPB
rel.results
noPB


###################################################


Art2006=ArtONC$"2006"
library(vegan)
heatmap(Art2006,scale='n')
heatmap(decostand(Art2006,'max',2),scale='n')


#Species Relationships
Art2006.rz<-decostand(Art2006[,apply(Art2006,2,sum)!=0],'max',2) #relativized and zeros removed
spp.dist<-vegdist(t(Art2006.rz),method='bray',upper=TRUE,diag=TRUE)

spp.clust<-hclust(spp.dist)
plot(spp.clust)
names(spp.clust)
spp.clust$height

r.com=array(sample(Art2006),length(Art2006),dim=dim(Art2006))#random matrix comparison
colnames(r.com)=colnames(Art2006)
colnames(r.com)=colnames(Art2006)
r.com.rz<-decostand(r.com,'max',2) #relativized and zeros removed
r.com.dist<-vegdist(t(r.com.rz),method='bray',upper=TRUE,diag=TRUE)

r.com.clust<-hclust(r.com.dist)
plot(r.com.clust)

#SPECIES ACCUMULATIONS
library(vegan)
par(mfrow=c(1,2))
barplot(sort(apply(Art2006,2,sum),decreasing=TRUE),las=2)
rownames(Art2006)
plot(specaccum(Art2006))
#Extract Genotype info
geno<-read.xls("/Users/artemis/Documents/R_Docs/Art Keith/Art ONC Arthropods/2006 arthropod data from Art.xls",header=FALSE)[1,-1]
geno=data.frame(geno)
x=character()
for (i in 1:length(geno)){
	x[i]=geno[i]
	}
geno=character()
for (i in 1:length(x)){
	geno[i]=as.character(x[[i]])
	}
geno2006=factor(geno)

#Analysis of genotype effect on community composition
adonis(Art2006~geno2006) #un-relativized
Art2006.relspm<-decostand(Art2006,"max",2)
adonis(Art2006.relspm~geno2006)#relativized by species max
Art2006.relspm[1:3,1:3]
adonis(Art2006[,-61]~geno2006) #un-relativized no P. betae
Art2006.nozeros=Art2006[,apply(Art2006,2,sum)!=0] #remove zero species
adonis(Art2006.nozeros~geno2006)
colnames(Art2006.nozeros)[46]
adonis(Art2006.nozeros[,-46]~geno2006) #remove PB
adonis(decostand(Art2006.nozeros,'max',2)~geno2006) #relativized
mrpp(decostand(Art2006.nozeros,'max',2),geno2006)

#Sort community matrix by total species abundances
Art2006.sortsppabun<-Art2006[,order(apply(Art2006,2,sum),decreasing=TRUE)]
Art2006.sortsppabun[1:3,1:3]
summary(aov(Art2006.sortsppabun[,1]~geno2006))
apply(Art2006.sortsppabun,2,sum)[1]/apply(Art2006.sortsppabun,2,sum)[2]

#Species Accumulation Curves
plot(specaccum(Art2006[geno==levels(geno2006)[9],]))

#Random selection of 7 genotypes
rgeno=sample(levels(geno2006),7,replace=FALSE)
out=array(NA,c(7,ncol(Art2006)))
x=matrix()
for (i in 1:length(rgeno)){
	x=Art2006[geno==rgeno[i],]
	out[i,]=x[sample(1:nrow(x),1),]
	}	
rg.com<-out
colnames(rg.com)<-colnames(Art2006)
rownames(rg.com)<-rgeno
plot(specaccum(rg.com))

#RANDOM GENO COMPARISON SCRIPT
quartz("Geno Comparison",7,7)
par(mfrow=c(3,3))
for (i in 1:nlevels(geno2006)){
plot(specaccum(Art2006[geno==levels(geno2006)[i],]),main=levels(geno2006)[i])

#Random selection of the genotypes, excluding comparison genotype
n=nrow(Art2006[geno==levels(geno2006)[i],])#number of observations
rgeno=sample(levels(geno2006),n,replace=FALSE)
out=array(NA,c(n,ncol(Art2006)))
x=matrix()
for (j in 1:length(rgeno)){
	x=Art2006[geno==rgeno[j],]
	out[j,]=x[sample(1:nrow(x),1),]
	}	
rg.com<-out
colnames(rg.com)<-colnames(Art2006)
rownames(rg.com)<-rgeno
plot(specaccum(rg.com),add=TRUE,col='red')
	
	}

#RANDOM GENO COMMUNITY FUNCTION
rgeno<-function(x,g,i){
Art2006=x
geno2006=g
n=nrow(Art2006[geno==levels(geno2006)[i],])#number of observations
rgeno=sample(levels(geno2006),n,replace=FALSE)
out=array(NA,c(n,ncol(Art2006)))
x=matrix()
for (j in 1:length(rgeno)){
	x=Art2006[geno==rgeno[j],]
	out[j,]=x[sample(1:nrow(x),1),]
	}	
rg.com<-out
colnames(rg.com)<-colnames(Art2006)
rownames(rg.com)<-rgeno	
return(rg.com)
	}

#Relativized Data
Art2006.relmax<-decostand(Art2006,'max',2)
plot(specaccum(Art2006.relmax))
plot(specaccum(Art2006))

#Presence Absence
Art2006.pa<-decostand(Art2006,'pa',2)
plot(specaccum(Art2006.pa,method='rand'))
plot(specaccum(Art2006))



#Side by side
par(mfrow=c(1,2))
plot(specaccum(Art2006[geno==levels(geno2006)[9],],method="rand"),main=levels(geno2006)[9])
plot(specaccum(rg.com,method="rand"),main="Random Geno")

#Indicator Species Analysis
library(labdsv)
Art2006.ISA<-duleg(Art2006,clustering=geno2006)
summary(Art2006.ISA)
names(Art2006.ISA)
Art2006.ISA$indval
detach(package:labdsv)

#Concordance
#Remove the un-observed species
#zero vector
is.zero
Art2006[,-apply(Art2006,2,sum)]
kendall.global(Art2006.rm0,geno2006)



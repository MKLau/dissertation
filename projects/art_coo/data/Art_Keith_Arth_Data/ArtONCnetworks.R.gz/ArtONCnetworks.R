#Reading Art's data files
source('/Users/aeolus/Documents/R_Docs/EcoNet/EcoNet_03.R')
source('/Users/Aeolus/Documents/Active_Projects/GeneticNetworks/Genetic_Networks/ind_net.R')
library(vegan)
library(sna)
library(bipartite)

#com.match
com.match=function(x,y){
	out=logical()
	for (i in seq(along=x)){
		out[i]=any(y==x[i])		
		}
	return(out)
	}

#com2troph

com2troph=function(x,troph='species, trophic level data frame'){
	#order by the species names to coallesce the trophic and abundance information
	troph=troph[order(troph[,1]),] 
	x=x[,order(colnames(x))]
	
if (all(colnames(x)==troph[,1])!=TRUE){return("ERROR: Species information does not match. Check using com.match.");stop()}else{}

	out=array(NA,c(nrow(x),nlevels(troph[,2])))
	colnames(out)=levels(troph[,2])
	rownames(out)=rownames(x)

	for (i in seq(along=levels(troph[,2]))){
		out[,i]=apply(x[,troph[,2]==levels(troph[,2])[i]],1,sum)
		}
return(out)	
	}

#barplot3
barplot3=function(x,se,ordering=TRUE,ylab=''){
	require(gplots,quietly=TRUE)
if (ordering==TRUE){
	se=se[order(x,decreasing=TRUE)]
	x=x[order(x,decreasing=TRUE)]
	}
else {}
barplot2(x,plot.ci=TRUE,ci.u=(x+se),ci.l=(x-se),ylab=ylab)
	}

#Standard Error Function
se=function(x){sd(x)/sqrt(length(x))}

#Use the response statistic = (I-O)/(I+O)
rs=function(x){if ((x[1]-x[2])==0){0}else{(x[1]-x[2])/(sum(x))}}

#Presence absence function
bin.sum=function(x){x[x!=0]<-1;sum(x)}

read.art=function(file=""){
x<-read.xls(file,header=TRUE)
xspp<-x[,1]
x<-x[,-1]
x<-t(x)
colnames(x)<-xspp
return(x)
	}

g2y.func=function(x){
	
	y=list()

for (i in seq(along=rownames(x[[1]]))){

z=array(NA,c(length(x),ncol(x[[1]])))
colnames(z)=colnames(x[[1]])
rownames(z)=paste(rownames(x[[1]])[i],names(x),sep='.')

	for (j in seq(along=names(x))){		
		z[j,]=x[[j]][i,]
		}
y[[i]]=z

	}	
	
names(y)=rownames(x[[1]])
	
	return(y)
	
	}

l2net=function(x){
	for (i in seq(along=names(x))){
d=vegdist(t(x[[i]])[apply(t(x[[i]]),1,sum)>3,])
x[[i]]=ind.net(as.matrix(d),1)
	}
	return(x)
	}

tp.rm=function(x){
	if (sum(x)==0){x=0}else if(all(x==x[1])){x=x[1]}else{
	p=t.test(x,alternative='greater')$p.value
	if (p<=0.05){x=mean(x)}else{x=0}
		}
	return(x)
	}

mu.d=function(x){

d=list()

for (i in seq(along=names(x))){
	x[[i]]=x[[i]][,apply(x[[i]],2,sum)>1]
	d[[i]]=apply(x[[i]],2,dist)
	d[[i]]=apply(d[[i]],2,tp.rm)
	}
names(d)=names(x)
return(d)
	
	}

#Mean abundance across years
mu.a=function(x){

out=list()

for (i in seq(along=names(x))){
	x[[i]]=x[[i]][,apply(x[[i]],2,sum)>1]
	out[[i]]=apply(x[[i]],2,tp.rm)
	}
names(out)=names(x)
return(out)
	
	}

#Convert the lists of genotypes back to a matrix. Note: all of the matrixes within the list have to have the same number of columns
list2matrix=function(x){
	
	for (i in seq(along=names(x))){
		if (i==1){y=x[[1]]}else{
			y=rbind(y,x[[i]])
			}	
		}
	return(y)
	}

###NOTE!!! Fly (dance) in 2004 and 2005 was changed to Fly (Dolichopodidae) given the posibility of calling a Dolichopodidae, long legged fly, a "dance fly" and given that it was nearly un-detected in 2005 and not detected in 2004.

library(gdata)
setwd("/Users/aeolus/Documents/R_Docs/Art_Keith/ArtONCArthropods")
ArtONC=list()
for (i in 1:3){
ArtONC[[i]]=read.art(dir()[i])
names(ArtONC)[i]=strsplit(dir()[i],split=" ")[[1]][1]
	}
names(ArtONC)
all(colnames(ArtONC[[1]])==colnames(ArtONC[[2]]))
all(colnames(ArtONC[[2]])==colnames(ArtONC[[3]]))

geno=list()
for (i in 1:3){
geno[[i]]<-read.xls(dir()[i],header=FALSE)[1,-1]
names(geno)[i]=paste("geno",strsplit(dir()[i],split=" ")[[1]][1],sep="_")	
	}

g2006=character()
x=""
for (i in 1:nrow(ArtONC$'2006')){

if (strsplit(rownames(ArtONC$'2006')[i],split='')[[1]][1]=="X"){
	for (j in 1:5){	
	x[j]=strsplit(rownames(ArtONC$'2006')[i],split='')[[1]][j]
	}
g2006[i]=paste(x[1],x[2],x[3],x[4],x[5],sep="")
}
else {
for (j in 1:4){	
	x[j]=strsplit(rownames(ArtONC$'2006')[i],split='')[[1]][j]
	}
g2006[i]=paste(x[1],x[2],x[3],x[4],sep="")
}

}

g2005=character()
x=""
for (i in 1:nrow(ArtONC$'2005')){

if (strsplit(rownames(ArtONC$'2005')[i],split='')[[1]][1]=="X"){
	for (j in 1:5){	
	x[j]=strsplit(rownames(ArtONC$'2005')[i],split='')[[1]][j]
	}
g2005[i]=paste(x[1],x[2],x[3],x[4],x[5],sep="")
}
else {
for (j in 1:4){	
	x[j]=strsplit(rownames(ArtONC$'2005')[i],split='')[[1]][j]
	}
g2005[i]=paste(x[1],x[2],x[3],x[4],sep="")
}

}

g2004=character()
x=""
for (i in 1:nrow(ArtONC$'2004')){

if (strsplit(rownames(ArtONC$'2004')[i],split='')[[1]][1]=="X"){
	for (j in 1:5){	
	x[j]=strsplit(rownames(ArtONC$'2004')[i],split='')[[1]][j]
	}
g2004[i]=paste(x[1],x[2],x[3],x[4],x[5],sep="")
}
else {
for (j in 1:4){	
	x[j]=strsplit(rownames(ArtONC$'2004')[i],split='')[[1]][j]
	}
g2004[i]=paste(x[1],x[2],x[3],x[4],sep="")
}

}

#Separate Communities by Year and Genotype
Art06=list()
for (i in 1:length(unique(g2006))){
	Art06[[i]]=ArtONC$'2006'[g2006==unique(g2006)[i],]
	names(Art06)[i]=unique(g2006)[i]
	}
length(names(Art06))

Art05=list()
for (i in 1:length(unique(g2005))){
	Art05[[i]]=ArtONC$'2005'[g2005==unique(g2005)[i],]
	names(Art05)[i]=unique(g2005)[i]
	}
length(names(Art05))

Art04=list()
for (i in 1:length(unique(g2004))){
	Art04[[i]]=ArtONC$'2004'[g2004==unique(g2004)[i],]
	names(Art04)[i]=unique(g2004)[i]
	}
length(names(Art04))

names(Art04)==names(Art05)
names(Art05)==names(Art06)

#Generate Networks 
###Removing heterogeneous estimates and using spearman's rho
library(sna)
DC.all=list()
DC=numeric()
Q06=list()
Q05=list()
Q04=list()
A=0
d=0.2
a=0.05
for (i in 1:length(Art06)){
A=econet(t(Art06[[i]]),d=d,a=a,rank.transform=TRUE,bonf=TRUE,hetero=TRUE)
DC[i]=centralization(A$'q',FUN='degree',mode='graph',normalize=TRUE)
Q06[[i]]=A$'q'
}

names(Q06)=names(Art06)
DC.all[[1]]=DC
names(DC.all)[1]=paste("Art06","DC",sep="")

for (i in 1:length(Art05)){
A=econet(t(Art05[[i]]),d=d,a=a,rank.transform=TRUE,bonf=TRUE,hetero=TRUE)
DC[[i]]=centralization(A$'q',FUN='degree',mode='graph',normalize=TRUE)
Q05[[i]]=A$'q'
}

names(Q05)=names(Art05)
DC.all[[2]]=DC
names(DC.all)[2]=paste("Art05","DC",sep="")

for (i in 1:length(Art04)){
A=econet(t(Art04[[i]]),d=d,a=a,rank.transform=TRUE,bonf=TRUE,hetero=TRUE)
DC[i]=centralization(A$'q',FUN='degree',mode='graph',normalize=TRUE)
Q04[[i]]=A$'q'
}

names(Q04)=names(Art04)
DC.all[[3]]=DC
names(DC.all)[3]=paste("Art04","DC",sep="")

X=cbind(DC.all[[1]],DC.all[[2]],DC.all[[3]])
colnames(X)=names(DC.all)

source('/Users/artemis/Documents/R_Docs/Scripts/Functions/pairs.R')
Y=cbind(X[,3],X[,2],X[,1])
colnames(Y)=c('2004','2005','2006')
pairs(Y,labels=paste("Degree Centrality ","(",colnames(Y),")",sep=""),lower.panel=panel.cor,upper.panel=panel.lm)

summary(lm(Y[,2]~Y[,1]))
summary(lm(Y[,3]~Y[,2]))

cor.test(Y[,1],Y[,2],method='p',alternative='great')
cor.test(Y[,2],Y[,3],method='p',alternative='great')

#Network Graphs
quartz('',9,9,bg=NULL)
par(mfrow=c(3,3),col.main='black')
edgecol='grey'
vertexcol='red'
vertexborder='grey'
for (i in 1:length(Q06)){

gplot(abs(as.matrix(Q06[[i]])),gmode='graph',edge.col=edgecol,vertex.col=vertexcol,vertex.border=vertexborder,edge.lwd=(abs(Q06[[i]])*10))
title(main=paste(names(Q06)[i],round(X[i,1],5),nrow(Q06[[i]])),col='black')
mtext('2006',outer=FALSE)
	}


quartz('',9,9,bg=NULL)
par(mfrow=c(3,3),col.main='black')
for (i in 1:length(Q05)){

gplot(abs(as.matrix(Q05[[i]])),gmode='graph',edge.col=edgecol,vertex.col=vertexcol,vertex.border=vertexborder,edge.lwd=(abs(Q05[[i]])*10))
title(main=paste(names(Q05)[i],round(X[i,1],5),nrow(Q05[[i]])),col='black')
mtext('2005',outer=FALSE)
	}

quartz('',9,9,bg=NULL)
par(mfrow=c(3,3),col.main='black')
for (i in 1:length(Q04)){

gplot(abs(as.matrix(Q04[[i]])),gmode='graph',edge.col=edgecol,vertex.col=vertexcol,vertex.border=vertexborder,edge.lwd=(abs(Q04[[i]])*10))
title(main=paste(names(Q04)[i],round(X[i,1],5),nrow(Q04[[i]])),col='black')
mtext('2004',outer=FALSE)
	}

gplot(abs(as.matrix(Q04[[i]])),displaylabels=TRUE,gmode='graph',edge.col=edgecol,vertex.col=vertexcol,vertex.border=vertexborder,edge.lwd=(abs(Q04[[i]])*10))

###P.betae resistant trees
names(Q06)
par(mfrow=c(1,2),col.main='white')
gplot(as.matrix(Q04$'X1008'),gmode='graph',edge.col='lightblue',vertex.col='white',vertex.border='white',edge.lwd=(abs(Q04$'X1008')*10),displaylabels=TRUE,label.col='white',boxed.labels=FALSE)
title('1008',col='white')
gplot(as.matrix(Q04$'X1020'),gmode='graph',edge.col='lightblue',vertex.col='white',vertex.border='white',edge.lwd=(abs(Q04$'X1020')*10),displaylabels=TRUE,label.col='white',boxed.labels=FALSE)
title('1020',col='white')

par(mfrow=c(1,2),col.main='white')
gplot(as.matrix(Q04$'X1008'),gmode='graph',edge.col='lightblue',vertex.col='white',vertex.border='white',edge.lwd=(abs(Q04$'X1008')*10),displaylabels=TRUE,label.col='white',boxed.labels=FALSE,mode='circle')
title('1008',col='white')
gplot(as.matrix(Q04$'X1020'),gmode='graph',edge.col='lightblue',vertex.col='white',vertex.border='white',edge.lwd=(abs(Q04$'X1020')*10),displaylabels=TRUE,label.col='white',boxed.labels=FALSE,mode='circle')
title('1020',col='white')

###P. betae susceptible trees
names(Art06)
pb.mu.06=numeric()

for (i in 1:length(Art06)){
pb.mu.06[i]=mean(Art06[[i]][,colnames(Art06[[i]])=='PB Gall'])
	}

barplot(pb.mu.06[order(pb.mu.06)],names=names(Art06)[order(pb.mu.06)],las=2)

names(Q06)
q=Q06$'WC.5'
rownames(q)=colnames(q)=paste('SP',1:ncol(q),sep='')
par(mfrow=c(1,2))
gplot(q,displaylabels=TRUE,usearrows=FALSE,boxed.labels=FALSE,edge.col='lightblue',vertex.lty=0,edge.lwd=10,vertex.col='violet')
qd=degree(q,gmode='graph',ignore.eval=TRUE,rescale=FALSE)
#barplot(qd[order(qd,decreasing=TRUE)],names=rownames(q)[order(qd,decreasing=TRUE)],las=2,ylab='Degree Centrality',col='violet')
barplot(qd,names=1:length(rownames(q)),las=2,ylab='Degree Centrality',col='violet',las=2,xlab='Species')


###Does the number of observations affect the degree centrality? No!
DC.all

N.all=list()
N=numeric()
Art.all=list(Art04,Art05,Art06)
names(Art.all)=c('Art04','Art05','Art06')

for (i in 1:length(Art.all)){
names(Art.all[[i]][2])
	for (j in 1:length(Art.all[[i]])){
		N[j]=nrow(Art.all[[i]][[j]])
		}
	N.all[[i]]=N
	N=numeric()
	}
N=N.all[[1]]

plot(c(DC.all[[1]],DC.all[[2]],DC.all[[3]])~rep(N,3),col=rainbow(length(DC.all))[gl(3,9)],xlab='Number of Trees',ylab='Degree Centrality',xaxt='none')
axis(1,at=4:7)

for (i in 1:length(DC.all)){
	abline(lm(DC.all[[i]]~N),col=rainbow(length(DC.all))[i])
	}
#legend('topright',legend=names(DC.all),fill=rainbow(3)[1:3])
legend('topright',legend=c("2006","2005","2004"),fill=rainbow(3)[1:3],bty='n')

####Test for degree centrality significance
#
#Art040506=list(Art06,Art05,Art04)
#names(Art040506)=c('Art06','Art05','Art04')
#out=list(0,0,0)
#for (i in 1:length(Art040506)){
#
#	for (j in 1:length(Art040506[[i]])){
#		
#	out[[i]][j]=DC.test(Art040506[[i]][[j]],n=1000,histogram=FALSE)$p.less
#		
#		}
#	names(out)=names(Art040506)
#	}
#
#x=out
#par(mfrow=c(1,3))
#barplot(x[[1]],names=names(Art06),las=2)
#abline(h=0.05)
#barplot(x[[2]],names=names(Art05),las=2)
#abline(h=0.05)
##barplot(x[[3]],names=names(Art04),las=2)
#abline(h=0.05)

###Plot Network Graphs


###Yearwise plots of degree centrality

#source('/Users/artemis/Documents/R_Docs/Scripts/Functions/pairs.R')
#pairs(X,lower.panel=panel.cor,upper.panel=panel.lm)

#Stability Estimates
colnames(ArtONC$'2004')==colnames(ArtONC$'2005')
colnames(ArtONC$'2005')==colnames(ArtONC$'2006')
colnames(ArtONC$'2004')==colnames(ArtONC$'2006')

library(vegan)

t1=ArtONC$'2004'
t2=ArtONC$'2005'
t3=ArtONC$'2006'

#Merged 05 and 06 species
t2=read.csv('/Users/artemis/Documents/R_Docs/Art Keith/ArtONCnetworkRESULTS/ArtONC05.csv')
t3=read.csv('/Users/artemis/Documents/R_Docs/Art Keith/ArtONCnetworkRESULTS/ArtONC06.csv')

colnames(t2)==colnames(t3)

###0405 Distances
colnames(t1)==colnames(t2)
rownames(t1)==rownames(t2)
out=array(NA,c(nrow(t1),1))
rownames(out)=rownames(t1)

for (i in 1:nrow(t1)){
	x=rbind(t1[i,],t2[i,])
	out[i,1]=vegdist(x)
	}

stab0405=out
geno0405="x"
for (i in 1:nrow(stab0405)){
	x=strsplit(rownames(stab0405)[i],split="")[[1]]
	if (x[1]=="X"){geno0405[i]=paste(x[1],x[2],x[3],x[4],x[5],sep="")}else {geno0405[i]=paste(x[1],x[2],x[3],x[4],sep="")
		}
	}
	
stab.mu0405=0

for (i in 1:length(unique(geno0405))){
stab.mu0405[i]=mean(stab0405[geno0405==unique(geno0405)[i],])
	}

barplot((1-as.numeric(stab.mu0405)),names=unique(geno0405))

###0506 Distances
colnames(t2)==colnames(t3)
rownames(t2)==rownames(t3)
out=array(NA,c(nrow(t2),1))
rownames(out)=rownames(t2)

for (i in 1:nrow(t2)){
	x=rbind(t2[i,],t3[i,])
	out[i,1]=vegdist(x)
	}

stab0506=out
geno0506="x"

for (i in 1:nrow(stab0506)){
	x=strsplit(rownames(stab0506)[i],split="")[[1]]
	if (x[1]=="X"){geno0506[i]=paste(x[1],x[2],x[3],x[4],x[5],sep="")}else {geno0506[i]=paste(x[1],x[2],x[3],x[4],sep="")
		}
	}
	
stab.mu0506=0

for (i in 1:length(unique(geno0506))){
stab.mu0506[i]=mean(stab0506[geno0506==unique(geno0506)[i],])
	}
	
barplot(as.numeric(stab.mu0506),names=unique(geno0506))
	
par(mfrow=c(1,2))
plot((1-stab.mu0405)[c(-7,-9)]~DC.all$Art04DC[c(-7,-9)],ylab='Mean Community Stability (2004-2005)',xlab='Degree Centrality (2004)',pch=16)
abline(lm((1-stab.mu0405)[c(-7,-9)]~DC.all$Art04DC[c(-7,-9)]))
legend('topleft',legend=paste("r =",round(cor((1-stab.mu0405)[c(-7,-9)],DC.all$Art04DC[c(-7,-9)]),2)),bty='n')

plot((1-stab.mu0506)[c(-7,-9)]~DC.all$Art05DC[c(-7,-9)],ylab='Bray-Curtis Similarity',xlab='Standardized Degree Centrality',pch=16,main='0506')
abline(lm((1-stab.mu0506[c(-7,-9)])~DC.all$Art05DC[c(-7,-9)]))

par(cex.lab=1.5)
plot((1-stab.mu0405)[c(-7,-9)]~DC.all$Art04DC[c(-7,-9)],ylab='',xlab='',pch=16,cex=1.5)
abline(lm((1-stab.mu0405)[c(-7,-9)]~DC.all$Art04DC[c(-7,-9)]))
title(ylab='Mean Community Stability (2004-2005)',xlab='Degree Centrality (2004)')
par(cex.lab=1)

cor.test((1-stab.mu0405)[c(-7,-9)],DC.all$Art04DC[c(-7,-9)],method='pearson',alternative='greater')
cor.test((1-stab.mu0506)[c(-7,-9)],DC.all$Art05DC[c(-7,-9)],method='pearson',alternative='greater')

#check the correlation with species richness and p. betae
library(vegan)
rich06=0
for (i in 1:length(Art06)){
rich06[i]=mean(specnumber(Art06[[i]]))
	}
rich05=0
for (i in 1:length(Art05)){
rich05[i]=mean(specnumber(Art05[[i]]))
	}
rich04=0
for (i in 1:length(Art04)){
rich04[i]=mean(specnumber(Art04[[i]]))
	}

quartz()
par(mfrow=c(1,2))
plot(rich04[c(-7,-9)]~DC.all$Art04DC[c(-7,-9)],xlab='Degree Centrality',ylab='Mean Species Richness')
abline(lm(rich04[c(-7,-9)]~DC.all$Art04DC[c(-7,-9)]))
summary(lm(rich04[c(-7,-9)]~DC.all$Art04DC[c(-7,-9)]))
plot(rich05[c(-7,-9)]~DC.all$Art05DC[c(-7,-9)],xlab='Degree Centrality',ylab='Mean Species Richness')
abline(lm(rich05[c(-7,-9)]~DC.all$Art05DC[c(-7,-9)]))
summary(lm(rich05[c(-7,-9)]~DC.all$Art05DC[c(-7,-9)]))

p.betae06=0
for (i in 1:length(Art06)){
p.betae06[i]=mean(Art06[[i]][,colnames(Art06[[i]])=='PB Gall'])
	}
p.betae05=0
for (i in 1:length(Art05)){
p.betae05[i]=mean(Art05[[i]][,colnames(Art05[[i]])=='PB Gall'])
	}
p.betae04=0
for (i in 1:length(Art04)){
p.betae04[i]=mean(Art04[[i]][,colnames(Art04[[i]])=='PB Gall'])
	}

barplot(p.betae06[order(p.betae06)],names=names(Art06)[order(p.betae06)],las=2)
barplot(p.betae05[order(p.betae05)],names=names(Art05)[order(p.betae05)],las=2)
barplot(p.betae04[order(p.betae04)],names=names(Art04)[order(p.betae04)],las=2)

plot(p.betae05,p.betae04)
pairs(list(p.betae06,p.betae05,p.betae04),labels=c("2006","2005","2004"))

quartz()
par(mfrow=c(1,2))
plot(p.betae04[c(-7,-9)]~DC.all$Art04DC[c(-7,-9)],xlab='Degree Centrality',ylab=expression("Mean "*italic('P. betae')*" Galls"))
abline(lm(p.betae04[c(-7,-9)]~DC.all$Art04DC[c(-7,-9)]))
summary(lm(p.betae04[c(-7,-9)]~DC.all$Art04DC[c(-7,-9)]))
plot(p.betae05[c(-7,-9)]~DC.all$Art05DC[c(-7,-9)],xlab='Degree Centrality',ylab=expression("Mean "*italic('P. betae')*" Galls"))
abline(lm(p.betae05[c(-7,-9)]~DC.all$Art05DC[c(-7,-9)]))
summary(lm(p.betae05[c(-7,-9)]~DC.all$Art05DC[c(-7,-9)]))


###Species Level Centrality Scores
centralization(Q06[[1]])

###OVERLAY TROPHIC DATA
td=read.xls('/Users/Aeolus/Documents/R_Docs/Art Keith/For Matt ONCtrophicdata.xls')
length(td[,1])
length(colnames(t2))
test=logical()
for (i in 1:length(t2)){

	
	
	}
	
	
###Comparisons to random matrixes
source('/Users/artemis/Documents/R_Docs/ComSim/ComSim06.R')
i=9
rc=rand.com(4,mu=runif(nrow(Q06[[i]]),0,10),s=5)
plot.densities(rc)
erc=econet(t(rc$obs),rank.transform=TRUE)
par(mfrow=c(2,1))
gplot(erc$q,gmode='graph',main=centralization(erc$q,'degree'))
gplot(Q06[[i]],gmode='graph',main=centralization(Q06[[i]],'degree'))

mc.c=numeric()
M=Q06[[i]]
mc=999
for (i in 1:mc){
rc=rand.com(4,mu=runif(nrow(M),0,10),s=5)
erc=econet(t(rc$obs))	
mc.c[i]=centralization(erc$q,'degree')	
	}

hist((mc.c))
abline(v=centralization(M,'degree'))
abline(v=median(mc.c))
obs.c=centralization(M,'degree')
length(mc.c[mc.c<=obs.c])/mc



###MC Procedure, increase the Equivalence Test region until the resulting network stat of centrality is differet from a permuted community matrix
k=1
x=Art06[[i]] #original community matrix
mc=100
sim=numeric()
for (i in 1:mc){
	rx=apply(x,2,sample)
	erc=econet(t(rx),rank.transform=TRUE)
	sim[i]=centralization(erc$q,'degree')
	}

hist(sim)
a=0.05
di=0.1 #initial d
step=0.1
dmax=0.75 #maximum d
net.obs=econet(t(x),rank.transform=TRUE)
obs=centralization(net.obs$q,'degree')
abline(v=obs)
pmc.l=length(sim[sim>=obs])/length(sim)
pmc.u=length(sim[sim<=obs])/length(sim)

while (pmc.l>a&pmc.u>a&di<=(dmax-step)){
	net.obs=econet(t(x),rank.transform=TRUE,d=di)
	obs=centralization(net.obs$q,'degree')
	pmc.l=length(sim[sim>=obs])/length(sim)
	pmc.u=length(sim[sim<=obs])/length(sim)
	if (pmc.l>a&pmc.u>a){di=di+step}
	}
	
abline(v=obs,lty=2)
quartz(names(Art06)[k],7,7)
gplot(net.obs$q,displaylabels=TRUE)


#Assess dmax across all Art06
a=0.05
di=0.1 #initial d
step=0.1
dmax=0.75 #maximum d
mc=25
d.all=numeric()
for (k in 1:length(Art06)){
	
x=Art06[[k]] #original community matrix
sim=numeric()
for (i in 1:mc){
	rx=apply(x,2,sample)
	erc=econet(t(rx),rank.transform=TRUE)
	sim[i]=centralization(erc$q,'degree')
	}

net.obs=econet(t(x),rank.transform=TRUE)
obs=centralization(net.obs$q,'degree')
pmc.l=length(sim[sim>=obs])/length(sim)
pmc.u=length(sim[sim<=obs])/length(sim)

while (pmc.l>a&pmc.u>a&di<=(dmax-step)){
	net.obs=econet(t(x),rank.transform=TRUE,d=di)
	obs=centralization(net.obs$q,'degree')
	pmc.l=length(sim[sim>=obs])/length(sim)
	pmc.u=length(sim[sim<=obs])/length(sim)
	if (pmc.l>a&pmc.u>a){di=di+step}
	}
	
d.all[k]=di
print(k,quotes=FALSE)
	}



net.obs=econet(t(x),rank.transform=TRUE,d=0.7)
gplot(abs(net.obs$q),displaylabels=TRUE,mode='circle')

centralization((net.obs$q),'degree')
centralization(abs(net.obs$q),'degree')

abs(net.obs$q)

apply((net.obs$q),1,sum)

apply(net.obs$q,2,sum)


#Assess dmax across all Art06 using the first isolated species rule
a=0.05
di=0.1 #initial d
step=0.05
dmax=0.95 #maximum d
mc=25
d.all=numeric()
for (k in 1:length(Art06)){
	
x=Art06[[k]] #original community matrix

net.obs=econet(t(x),rank.transform=TRUE,d=di)
obs=centralization(abs(net.obs$q),'degree')

while (pmc.l>a&pmc.u>a&di<=(dmax-step)){
	net.obs=econet(t(x),rank.transform=TRUE,d=di)

	if (pmc.l>a&pmc.u>a){di=di+step}
	}
	
d.all[k]=di
print(k,quotes=FALSE)
	}


#Trophic Data
trophic=read.csv('/Users/Aeolus/Documents/R_Docs/Art_Keith/ONCArthropodTrophicData.csv')

attach(trophic)
troph=data.frame(Arthropod,Trophic.Level)
detach(trophic)

troph[com.match(troph[,1],colnames(Art04))==FALSE,1]

troph=troph[com.match(troph[,1],colnames(Art04)),]

troph04=com2troph(Art04,troph)
troph05=com2troph(Art05,troph)
troph06=com2troph(Art06,troph)

troph04=troph04[,c(2,1,5,3,6,4)]

heatmap(troph04)
pairs(troph04,lower.panel=panel.hccor,upper.panel=panel.lmr)
pairs(troph05,lower.panel=panel.hccor,upper.panel=panel.lmr)
pairs(troph06,lower.panel=panel.hccor,upper.panel=panel.lmr)

library(vegan)
library(ecodist)

for (i in seq(along=rownames(Art04))){
	y=strsplit(as.character(rownames(Art04)[i]),split='\\.')[[1]]
	if (length(y)==1){g2004[i]=y}else{g2004[i]=paste(y[1],y[2],sep='.')}
	}

troph.nms04=nmds(vegdist(troph04),2,2,nits=10)
troph.nms04=nmds.min(troph.nms04,2)
plot(troph.nms04,col=as.numeric(factor(g2004)))

plotweb(troph04[order(apply(troph04,1,sum)),order(apply(troph04,2,sum))],method='norm')

library(rgl)
plot3d(Herb,Pred,Omni,data=troph04)

summary(trophic)
trophic[order(trophic[,1]),]

#remove unknown species
trophic=trophic[trophic$Troph!=0,]

#Make the adjacency matrix
t.names=character(nrow(trophic))
attach(trophic)
for (i in 1:nrow(trophic)){
	if (Genus[i]=='unk'&Family[i]=='unk'&Order[i]=='unk'){
	t.names[i]=paste(strsplit(as.character(Arthropod[i]),split=" ")[[1]][1],Species[i],sep="")
		}else if (Genus[i]=='unk'&Family[i]=='unk'){
	t.names[i]=paste(strsplit(as.character(Order[i]),split=" ")[[1]][1],Species[i],sep="")
		}else if (Genus[i]=='unk'){
	t.names[i]=paste(strsplit(as.character(Family[i]),split=" ")[[1]][1],Species[i],sep="")
		}else {
	t.names[i]=paste(strsplit(as.character(Genus[i]),split=" ")[[1]][1],Species[i],sep=".")
		}

	}


t.A=array(NA,c(length(t.names),length(t.names)))
colnames(t.A)<-rownames(t.A)<-t.names
names(trophic)

for (i in 1:nrow(t.A)){
	for (j in 1:ncol(t.A)){
		if (Troph[i]==0&Troph[j]==0){t.A[i,j]=1}else if(Troph[i]==0|Troph[j]==0){t.A[i,j]=0}else if (Troph[i]-Troph[j]==1){t.A[i,j]=1}else{t.A[i,j]=0}
		}
	}
image(t.A)

library(sna)
gplot(t.A,vertex.col=(Troph+2))
plot.new()
gplot3d(t.A,edge.lwd=0.3,displaylabels=FALSE,vertex.col=Troph,vertex.radius=2,edge.col='grey')
t.levels=unique(paste(Troph,Trophic.Level,sep='='))
t.levels=t.levels[order(t.levels)]
plot.new()
legend('top',legend=t.levels,bty='n',pch=16,col=1:5,pt.cex=1.5)

quartz()
plot.new()
barplot(table(Troph)/sum(table(Troph)),xlab='Trophic Level',ylim=c(0,0.5),ylab='Percent of Total Species')

detach(trophic)


#Analyze trophic level abundances on each genotype
#Matching up trophic species names with the species names in the genotypes
troph.merge=read.csv('/Users/artemis/Documents/R_Docs/Art Keith/ArtONCTrophicDataMerge2.csv')
troph.merge[,1]==colnames(ArtONC[[1]])[order(colnames(ArtONC[[1]]))]

hist(troph.merge$Troph)

trophic=troph.merge
trophic=trophic[trophic$Troph!=0,]#REMOVE UNKNOWN SPECIES WITH TROPHIC STATUS

#Make the adjacency matrix
t.names=character(nrow(trophic))
attach(trophic)
for (i in 1:nrow(trophic)){
	if (Genus[i]=='unk'&Family[i]=='unk'&Order[i]=='unk'){
	t.names[i]=paste(strsplit(as.character(Arthropod[i]),split=" ")[[1]][1],Species[i],sep="")
		}else if (Genus[i]=='unk'&Family[i]=='unk'){
	t.names[i]=paste(strsplit(as.character(Order[i]),split=" ")[[1]][1],Species[i],sep="")
		}else if (Genus[i]=='unk'){
	t.names[i]=paste(strsplit(as.character(Family[i]),split=" ")[[1]][1],Species[i],sep="")
		}else {
	t.names[i]=paste(strsplit(as.character(Genus[i]),split=" ")[[1]][1],Species[i],sep=".")
		}

	}

t.A=array(NA,c(length(t.names),length(t.names)))
colnames(t.A)<-rownames(t.A)<-t.names
names(trophic)

for (i in 1:nrow(t.A)){
	for (j in 1:ncol(t.A)){
		if (Troph[i]==0&Troph[j]==0){t.A[i,j]=1}else if(Troph[i]==0|Troph[j]==0){t.A[i,j]=0}else if (Troph[i]-Troph[j]==1){t.A[i,j]=1}else{t.A[i,j]=0}
		}
	}
image(t.A)

library(sna)
gplot(t.A,vertex.col=(Troph+2))
plot.new()
gplot3d(t.A,edge.lwd=0.3,displaylabels=FALSE,vertex.col=Troph,vertex.radius=2,edge.col='grey')
t.levels=unique(paste(Troph,Trophic.Level,sep='='))
t.levels=t.levels[order(t.levels)]
plot.new()
legend('top',legend=t.levels,bty='n',pch=16,col=1:5,pt.cex=1.5)

quartz()
plot.new()
barplot(table(Troph)/sum(table(Troph)),xlab='Trophic Level',ylim=c(0,0.5),ylab='Percent of Total Species')

detach(trophic)

#Function to create an flow/adjacency matrix given an input matrix of species names and occurrences (p x 2) and a matrix of species names and relationships (p x 2).
flow.net=function(x,y){
y=y[order(y[,1]),];x=x[order(x[,1]),]
y=y[x[,2]!=0,];x=x[x[,2]!=0,]

z=array(NA,c(nrow(x),nrow(x)))
colnames(z)<-rownames(z)<-x[,1]
for (i in 1:nrow(z)){
	for (j in 1:nrow(z)){
		if ((y[i,2]-y[j,2])==1){z[i,j]=1}else{z[i,j]=0}
		}
	}
return(z)
	}

quartz('ArtONC04',7.5,7.5)
par(mfrow=c(3,3))
for (i in 1:length(Art04)){
x=apply(Art04[[i]],2,mean)
x[x!=0]<-1
Arthopod.names=names(x)
x=data.frame(Arthopod.names,x,row.names=1:length(x))
attach(trophic)
y=data.frame(Arthropod,Troph)
detach(trophic)

gplot(flow.net(x,y),main=names(Art04)[i])
	}

quartz('ArtONC05',7.5,7.5)
par(mfrow=c(3,3))
for (i in 1:length(Art05)){
x=apply(Art05[[i]],2,mean)
x[x!=0]<-1
Arthopod.names=names(x)
x=data.frame(Arthopod.names,x,row.names=1:length(x))
attach(trophic)
y=data.frame(Arthropod,Troph)
detach(trophic)

gplot(flow.net(x,y),main=names(Art05)[i])
	}
	
quartz('ArtONC06',7.5,7.5)
par(mfrow=c(3,3))
for (i in 1:length(Art06)){
x=apply(Art04[[i]],2,mean)
x[x!=0]<-1
Arthopod.names=names(x)
x=data.frame(Arthopod.names,x,row.names=1:length(x))
attach(trophic)
y=data.frame(Arthropod,Troph)
detach(trophic)

gplot(flow.net(x,y),main=names(Art06)[i])
	}

gplot(flow.net(x,y),main=names(Art06)[i],displaylabels=TRUE)

#Analyzing the trophic distribution of each genotype
troph04=list()
quartz('Art04',7.9,7.9)
par(mfrow=c(3,3))
for (i in 1:length(Art04)){
x=apply(Art04[[i]],2,mean)
x[x!=0]<-1
Arthopod.names=names(x)
x=data.frame(Arthopod.names,x,row.names=1:length(x))
attach(trophic)
y=data.frame(Arthropod,Troph)
detach(trophic)
y=y[order(y[,1]),];x=x[order(x[,1]),]
y=y[x[,2]!=0,]
hist(y$Troph,xlab='Trophic Level',main=names(Art04)[i])
troph04[[i]]=Trophic.Level
	}

quartz('Art05',7.9,7.9)
par(mfrow=c(3,3))
troph05=list()
for (i in 1:length(Art05)){
x=apply(Art05[[i]],2,mean)
x[x!=0]<-1
Arthopod.names=names(x)
x=data.frame(Arthopod.names,x,row.names=1:length(x))
attach(trophic)
y=data.frame(Arthropod,Troph)
detach(trophic)
y=y[order(y[,1]),];x=x[order(x[,1]),]
y=y[x[,2]!=0,]
hist(y$Troph,xlab='Trophic Level',main=names(Art05)[i])
troph05[[i]]=Trophic.Level
	}
	
quartz('Art06',7.9,7.9)
par(mfrow=c(3,3))
troph06=list()
for (i in 1:length(Art06)){
x=apply(Art06[[i]],2,mean)
x[x!=0]<-1
Arthopod.names=names(x)
x=data.frame(Arthopod.names,x,row.names=1:length(x))
attach(trophic)
y=data.frame(Arthropod,Troph)
detach(trophic)
y=y[order(y[,1]),];x=x[order(x[,1]),]
y=y[x[,2]!=0,]
hist(y$Troph,xlab='Trophic Level',main=names(Art06)[i])
troph06[[i]]=Trophic.Level
	}

#Isolating the trophic structure for each tree in 2004
troph06=list()
z=Art06
k=1
for (i in 1:length(x)){
for (j in 1:nrow(z[[i]])){
x=z[[i]][j,]
x[x!=0]<-1
Arthopod.names=names(x)
x=data.frame(Arthopod.names,x,row.names=1:length(x))
attach(trophic)
y=data.frame(Arthropod,Troph)
detach(trophic)
troph06[[k]]=y[x[,2]==1,]
names(troph06)[k]=rownames(z[[i]])[j]
k=k+1
	}

	}
troph06



#Analyze biomass in the trophic levels using the dry weight from reference collections for each species (Bridgeland1)


#Networks by time replicates

names(Art06)

 HE.1=list()
 RM.2=list()  
 T.15=list()
 Coal=list()
 X1000=list()
 HE.8=list()
 X1020=list()
 WC.5=list()
 X1008=list()
	
	 HE.1[[1]]=Art04$'HE.1'
	 	 HE.1[[2]]=Art05$'HE.1'
		 	 HE.1[[3]]=Art06$'HE.1'

	 RM.2[[1]]=Art04$'RM.2'
	 	 RM.2[[2]]=Art05$'RM.2'
		 	 RM.2[[3]]=Art06$'RM.2'
		 	 
	 T.15[[1]]=Art04$'T.15'
	 	 T.15[[2]]=Art05$'T.15'
		 	 T.15[[3]]=Art06$'T.15'


	 Coal[[1]]=Art04$'Coal'
	 	 Coal[[2]]=Art05$'Coal'
		 	 Coal[[3]]=Art06$'Coal'

	 X1000[[1]]=Art04$'X1000'
	 	 X1000[[2]]=Art05$'X1000'
		 	 X1000[[3]]=Art06$'X1000'

	 HE.8[[1]]=Art04$'HE.8'
	 	 HE.8[[2]]=Art05$'HE.8'
		 	 HE.8[[3]]=Art06$'HE.8'

	 X1020[[1]]=Art04$'X1020'
	 	 X1020[[2]]=Art05$'X1020'
		 	 X1020[[3]]=Art06$'X1020'

	 WC.5[[1]]=Art04$'WC.5'
	 	 WC.5[[2]]=Art05$'WC.5'
		 	 WC.5[[3]]=Art06$'WC.5'

	 X1008[[1]]=Art04$'X1008'
	 	 X1008[[2]]=Art05$'X1008'
		 	 X1008[[3]]=Art06$'X1008'


	 names(HE.1)=c('04','05','06')
	 names(RM.2)  =c('04','05','06')
	 names(T.15)=c('04','05','06')
	 names(Coal)  =c('04','05','06')
	 names(X1000) =c('04','05','06')
	 names(HE.8)  =c('04','05','06')
	 names(X1020) =c('04','05','06')
	 names(WC.5)  =c('04','05','06')
	 names(X1008)=c('04','05','06')

	
he.10=g2y.func(HE.1)
rm.2=g2y.func(RM.2)
t.15=g2y.func(T.15)
coal=g2y.func(Coal)
x1000=g2y.func(X1000)
he.8=g2y.func(HE.8)
x1020=g2y.func(X1020)
wc.5=g2y.func(WC.5)
x1008=g2y.func(X1008)

#independence networks resulted in totally fragmented networks
#he.10=l2net(he.10)
#rm.2=l2net(rm.2)
#t.15=l2net(T.15)
#coal=l2net(coal)
#x1000=l2net(x1000)
#he.8=l2net(he.8)
#x1020=l2net(x1020)
#wc.5=l2net(wc.5)
#x1008=l2net(x1008)

#What about the rate of change in each species through time?
#Look at the BC distance for each species.
z=he.10[[1]]
z=z[,apply(z,2,sum)>1]
x=dist(z[,6])
t.test(as.numeric(x),alternative='greater')

#1 Get distance matrixes
#2 Test that the average distance is not zero
#3 Call all p-values greater than 0.05, average distance = 0


#md.he10=mu.d(he.10)
#md.rm2=mu.d(rm.2)
#md.t15=mu.d(t.15)
#md.coal=mu.d(coal)
#md.x1000=mu.d(x1000)
#md.he8=mu.d(he.8)
#md.x1020=mu.d(x1020)
#md.wc5=mu.d(wc.5)
#md.x1008=mu.d(x1008)
#
#md..=list(md.he10,md.rm2,md.t15,md.coal,md.x1000,md.he8,md.x1020,md.wc5,md.x1008)
#names(md..)=c('he10','rm2','t15','coal','x1000','he8','x1020','wc5','x1008')
#
#art.md=array(NA,c(sum(as.numeric(lapply(Art06,nrow))),ncol(Art06[[1]])))
#colnames(art.md)=colnames(Art06[[1]])

md.he10=mu.a(he.10)
md.rm2=mu.a(rm.2)
md.t15=mu.a(t.15)
md.coal=mu.a(coal)
md.x1000=mu.a(x1000)
md.he8=mu.a(he.8)
md.x1020=mu.a(x1020)
md.wc5=mu.a(wc.5)
md.x1008=mu.a(x1008)

md..=list(md.he10,md.rm2,md.t15,md.coal,md.x1000,md.he8,md.x1020,md.wc5,md.x1008)
names(md..)=c('he10','rm2','t15','coal','x1000','he8','x1020','wc5','x1008')

art.md=array(NA,c(sum(as.numeric(lapply(Art06,nrow))),ncol(Art06[[1]])))
colnames(art.md)=colnames(Art06[[1]])

for (i in seq(along=colnames(Art06[[1]]))){
l=1	
for (j in seq(along=names(md..))){
	
	for (k in seq(along=names(md..[[j]]))){
		if (length(names(md..[[j]][[k]])[names(md..[[j]][[k]])==colnames(Art06[[1]])[i]])!=0){art.md[l,i]=md..[[j]][[k]][names(md..[[j]][[k]])==colnames(Art06[[1]])[i]]}else{art.md[l,i]=0}
		
	l=l+1

		}

	}	
	
}
sum(art.md[1,])
sum(md..[[1]][[1]])
art.md.rownames=character()
for (i in seq(along=colnames(Art06[[1]]))){
l=1	
for (j in seq(along=names(md..))){
	
	for (k in seq(along=names(md..[[j]]))){

	art.md.rownames[l]=names(md..[[j]])[k]
	l=l+1

		}
	}		
}


rownames(art.md)=art.md.rownames

library(bipartite)

art.md=art.md[order(apply(art.md,1,sum),decreasing=TRUE),order(apply(art.md,2,sum),decreasing=TRUE)]

plotweb(art.md,method='normal')

art.md.pa=art.md[order(apply(art.md,1,bin.sum),decreasing=TRUE),order(apply(art.md,2,bin.sum),decreasing=TRUE)]
art.md.pa[art.md.pa>0]<-1

plotweb(art.md.pa,method='normal')
visweb(art.md.pa)

tree.el=apply(art.md,1,bin.sum)
spp.el=apply(art.md,2,bin.sum)


#Connectance
art.md.pa=art.md.pa[,apply(art.md.pa,2,sum)>0]
sum(art.md.pa)/(ncol(art.md.pa)*nrow(art.md.pa))

#Edge distributions
tree.hist=hist(tree.el)
hist(spp.el)

tree.ed=tree.el/ncol(art.md.pa)

#Test for the node distribtuion under a random model, indiciation of competitive exclusion or mutualism

#Under a random model what is the probability of 
art.shuf=shuffle.web(art.md,1000)

plotweb(art.shuf[[7]][order(apply(art.shuf[[7]],1,bin.sum),decreasing=TRUE),order(apply(art.shuf[[7]],2,bin.sum),decreasing=TRUE)],method='normal')

par(mfrow=c(1,2))
hist(apply(art.shuf[[7]],1,bin.sum))
hist(tree.el)

par(mfrow=c(1,2))
hist(apply(art.shuf[[7]],2,bin.sum))
hist(spp.el)


nested(art.md,method='wine')
shuf.nest=numeric()
for (i in seq(along=(1:length(art.shuf)))){
	shuf.nest[i]=nested(art.shuf[[i]],method='wine')
	}

visweb(art.md.pa)

hist(shuf.nest[is.na(shuf.nest)==FALSE],xlim=c(-0.5,0.5))
abline(v=nested(art.md,method='wine'),lty=2)

#Modularity
computeModules()

#Test for genotype effect
#Try strapply to get geno names
geno.el=c('rm2','t15','he10','coal3','x1000','he10','he8','coal3','he8','x1000','wc5','coal3','rm2','wc5','wc5','x1008','he10','x1020','t15','wc5','x1020','x1008','t15','wc5','x1020','he8','t15','x1020','x1008','he8','x1008','he10','he10','wc5','wc5','rm2','rm2','t15','coal3','x1000','x1000','x1020','x1008','x1008')

cbind(geno.el,names(tree.el))

summary(aov(tree.el~geno.el))

library(gplots)

par(mfrow=c(1,3))

barplot3(tapply(tree.el,geno.el,mean),tapply(tree.el,geno.el,se),ylab='Edge Number')

barplot3(tapply(tree.ed,geno.el,mean),tapply(tree.ed,geno.el,se),ylab='Edge Deviance')

art.nd=ND(art.md)$lower
art.bc=BC(art.md)$lower
art.cc=CC(art.md)$lower

barplot3(tapply(art.nd,geno.el,mean),tapply(art.nd,geno.el,se))
barplot3(tapply(art.bc,geno.el,mean),tapply(art.bc,geno.el,se))
barplot3(tapply(art.cc,geno.el,mean),tapply(art.cc,geno.el,se))


summary(aov(art.nd~factor(geno.el)))
summary(aov(art.bc~factor(geno.el)))
summary(aov(art.cc~factor(geno.el)))





#Is there intraspecific variation in the structure of interactions?
#Yes
#Present the bipartiate graph both weigted and unweighted
#Present shuffled graph
#Present the distribution of edge number


#How much is explained by genotype?
names(ArtONC)
web04=ArtONC[[1]]
web05=ArtONC[[2]]
web06=ArtONC[[3]]

web04=web04[order(apply(web04,1,sum),decreasing=TRUE),order(apply(web04,2,sum),decreasing=TRUE)]
web05=web05[order(apply(web05,1,sum),decreasing=TRUE),order(apply(web05,2,sum),decreasing=TRUE)]
web06=web06[order(apply(web06,1,sum),decreasing=TRUE),order(apply(web06,2,sum),decreasing=TRUE)]
par()$mar
par(mfrow=c(3,1))
plotweb(web04,method='normal')
plotweb(web05,method='normal')
plotweb(web06,method='normal')

visweb(web04)
visweb(web05)
visweb(web06)

web04

#Monopartite perspective: Examine shared interactions 





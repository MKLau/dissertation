#Examine the concordance of species from Art's datasets.

#The data are from this source file: /Users/Aeolus/Documents/R_Docs/Art Keith/ArtONCnetworks.R

names(ArtONC)

Art04=ArtONC$'2004'
Art05=ArtONC$'2005'
Art06=ArtONC$'2006'

#Check
all(colnames(Art04)==colnames(Art05))
all(colnames(Art04)==colnames(Art06))

#Remove low abundance species

X=rbind(Art04,Art05,Art06)
Art04=Art04[,apply(X,2,sum)/sum(apply(X,2,sum))>=0.01]
Art05=Art05[,apply(X,2,sum)/sum(apply(X,2,sum))>=0.01]
Art06=Art06[,apply(X,2,sum)/sum(apply(X,2,sum))>=0.01]

par(mfrow=c(1,2))
barplot(apply(X,2,sum)[order(apply(X,2,sum),decreasing=TRUE)],las=2)
abline(h=(sum(apply(X,2,sum))*0.05),lty=2,col='red')
abline(h=(sum(apply(X,2,sum))*0.01),lty=2)

X=rbind(Art04,Art05,Art06)
Art04=Art04[,apply(X,2,sum)/sum(apply(X,2,sum))>=0.01]
Art05=Art05[,apply(X,2,sum)/sum(apply(X,2,sum))>=0.01]
Art06=Art06[,apply(X,2,sum)/sum(apply(X,2,sum))>=0.01]

barplot(apply(X,2,sum)[order(apply(X,2,sum),decreasing=TRUE)],las=2)
abline(h=(sum(apply(X,2,sum))*0.05),lty=2,col='red')
abline(h=(sum(apply(X,2,sum))*0.01),lty=2)


#Hellinger transform the data first.

my.hell=function(x='sites X species'){
	x=x/apply(x,1,sum)
	x=sqrt(x)
	return(x)
	}

Art04.ht=my.hell(Art04)
Art05.ht=my.hell(Art05)
Art06.ht=my.hell(Art06)

library(vegan)

#1. Correlation analysis of species
#
cor(Art05.ht,method='spearman')


for (i in 1:length(unique(g2004))){
	print(kendall.global(Art04.ht[g2004==unique(g2004)[i],]))
	}

for (i in 1:length(unique(g2005))){
	print(kendall.global(Art05.ht[g2005==unique(g2005)[i],]))
	}

for (i in 1:length(unique(g2006))){
	print(kendall.global(Art06.ht[g2006==unique(g2006)[i],]))
	}

kendall.global(Art06.ht[g2006==unique(g2006)[1],apply(Art06.ht[g2006==unique(g2006)[1],],2,sum)>1])
kendall.global(Art06.ht[g2006==unique(g2006)[1],apply(Art06.ht[g2006==unique(g2006)[1],],2,sum)>=0])

kendall.post(Art06.ht[g2006==unique(g2006)[1],apply(Art06.ht[g2006==unique(g2006)[9],],2,sum)>0])
